package com.stev01.texturetomap;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

/**
 * Uses small reflective adapters around vanilla's map state so the clean-room implementation
 * is not tied to pre-26.2 intermediary/Yarn names. The actual map color buffer is populated at runtime.
 */
public final class MapBuilder {
    private MapBuilder() {}

    public static void create(ServerPlayer player, String textureId, byte[] pixels) {
        ServerLevel level = player.serverLevel();
        try {
            Class<?> mapItemClass = Class.forName("net.minecraft.world.item.MapItem");
            Method create = findCreate(mapItemClass);
            if (create == null) throw new IllegalStateException("Vanilla MapItem.create was not found");

            ItemStack stack = (ItemStack) create.invoke(null, level, player.blockPosition().getX(), player.blockPosition().getZ(), (byte) 0, false, false);
            Object mapState = findMapState(mapItemClass, stack, level);
            if (mapState == null) throw new IllegalStateException("Could not obtain map state");
            writeColors(mapState, pixels);
            player.getInventory().add(stack);
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("TextureToMap: created map from " + textureId));
        } catch (Throwable error) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("TextureToMap error: " + error.getClass().getSimpleName()));
        }
    }

    private static Method findCreate(Class<?> c) {
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals("create") || m.getParameterCount() != 6) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p[0].getName().equals("net.minecraft.server.level.ServerLevel") && p[1] == int.class && p[2] == int.class && p[3] == byte.class && p[4] == boolean.class && p[5] == boolean.class) {
                m.setAccessible(true);
                return m;
            }
        }
        return null;
    }

    private static Object findMapState(Class<?> mapItemClass, ItemStack stack, ServerLevel level) throws Exception {
        for (Method m : mapItemClass.getDeclaredMethods()) {
            if (!m.getName().equals("getSavedData") && !m.getName().equals("getMapState")) continue;
            if (m.getParameterCount() != 2) continue;
            try {
                m.setAccessible(true);
                Object result = m.invoke(null, stack, level);
                if (result != null) return result;
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private static void writeColors(Object state, byte[] pixels) throws Exception {
        Class<?> c = state.getClass();
        for (Field f : c.getDeclaredFields()) {
            f.setAccessible(true);
            Object value = f.get(state);
            if (value instanceof byte[] bytes && bytes.length == 128 * 128) {
                System.arraycopy(pixels, 0, bytes, 0, bytes.length);
                markDirty(state);
                return;
            }
            if (value instanceof ByteBuffer buffer && buffer.capacity() >= 128 * 128) {
                buffer.position(0);
                buffer.put(pixels, 0, 128 * 128);
                markDirty(state);
                return;
            }
        }
        throw new IllegalStateException("Map color buffer not found");
    }

    private static void markDirty(Object state) {
        try {
            Method setDirty = state.getClass().getMethod("setDirty");
            setDirty.invoke(state);
        } catch (Throwable ignored) {}
    }
}
