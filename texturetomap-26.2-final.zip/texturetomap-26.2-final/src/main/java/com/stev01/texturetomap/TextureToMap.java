package com.stev01.texturetomap;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.Commands;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

public final class TextureToMap implements ModInitializer {
    public static final String MOD_ID = "texturetomap";
    public static final Identifier PAYLOAD_ID = Identifier.fromNamespaceAndPath(MOD_ID, "create_map");

    public record CreateMapPayload(String textureId, byte[] pixels) implements CustomPacketPayload {
        public static final Type<CreateMapPayload> TYPE = new Type<>(PAYLOAD_ID);
        public static final StreamCodec<RegistryFriendlyByteBuf, CreateMapPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.stringUtf8(256), CreateMapPayload::textureId,
                ByteBufCodecs.byteArray(16384), CreateMapPayload::pixels,
                CreateMapPayload::new
        );

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.serverboundPlay().register(CreateMapPayload.TYPE, CreateMapPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CreateMapPayload.TYPE, (payload, context) -> {
            ServerPlayer player = context.player();
            if (payload.pixels().length != 128 * 128) return;
            context.server().execute(() -> MapBuilder.create(player, payload.textureId(), payload.pixels()));
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("texturemap")
                        .then(Commands.literal("help").executes(ctx -> {
                            ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal(
                                    "Use the TextureToMap key in the Controls screen, then enter a texture id such as minecraft:block/stone."), false);
                            return 1;
                        }))));
    }
}
