package com.stev01.texturetomap;

/** Vanilla-map style 8-bit color approximation. */
public final class MapColorQuantizer {
    private MapColorQuantizer() {}

    public static byte quantize(int argb) {
        int a = (argb >>> 24) & 255;
        if (a < 16) return 0;
        int r = (argb >>> 16) & 255;
        int g = (argb >>> 8) & 255;
        int b = argb & 255;
        int best = 0;
        int bestDist = Integer.MAX_VALUE;
        for (int i = 0; i < PALETTE.length; i++) {
            int dr = r - PALETTE[i][0], dg = g - PALETTE[i][1], db = b - PALETTE[i][2];
            int d = dr * dr + dg * dg + db * db;
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return (byte) best;
    }

    private static final int[][] PALETTE = {
            {0,0,0},{127,178,56},{247,233,163},{199,199,199},{255,0,0},{160,160,255},{167,167,167},{0,124,0},
            {255,255,255},{164,168,184},{151,109,77},{112,112,112},{64,64,255},{143,119,72},{255,252,245},{216,127,51},
            {178,76,216},{102,153,216},{229,229,51},{127,204,25},{242,127,165},{76,76,76},{153,153,153},{76,127,153},
            {127,63,178},{51,76,178},{102,76,51},{102,127,51},{153,51,51},{25,25,25},{250,238,77},{92,219,213},
            {74,128,255},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0}
    };
}
