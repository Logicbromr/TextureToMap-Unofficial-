package com.stev01.texturetomap;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class TextureToMapClient implements ClientModInitializer {
    private static KeyMapping key;

    @Override
    public void onInitializeClient() {
        key = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.texturetomap.create", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.texturetomap"));

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                literal("texturemap").then(argument("texture", StringArgumentType.greedyString())
                        .executes(ctx -> sendTexture(StringArgumentType.getString(ctx, "texture"))))));
    }

    private static int sendTexture(String idText) {
        Minecraft mc = Minecraft.getInstance();
        Identifier id = parseTexture(idText);
        if (id == null) {
            message("TextureToMap: invalid texture id");
            return 0;
        }
        try {
            byte[] pixels = loadTexture(mc, id);
            ClientPlayNetworking.send(new TextureToMap.CreateMapPayload(id.toString(), pixels));
            message("TextureToMap: sent " + id + " to the server");
            return 1;
        } catch (Exception e) {
            message("TextureToMap: could not load " + id + " (" + e.getClass().getSimpleName() + ")");
            return 0;
        }
    }

    private static Identifier parseTexture(String text) {
        String s = text.trim();
        if (s.startsWith("minecraft:")) return Identifier.tryParse(s);
        if (s.contains(":")) return Identifier.tryParse(s);
        return Identifier.tryParse("minecraft:" + s);
    }

    private static byte[] loadTexture(Minecraft mc, Identifier id) throws Exception {
        Identifier png = id.getPath().endsWith(".png") ? id : Identifier.fromNamespaceAndPath(id.getNamespace(), "textures/" + id.getPath() + ".png");
        try (InputStream in = mc.getResourceManager().getResourceOrThrow(png).open()) {
            BufferedImage image = ImageIO.read(in);
            if (image == null) throw new IllegalArgumentException("not a PNG image");
            byte[] result = new byte[128 * 128];
            for (int y = 0; y < 128; y++) {
                for (int x = 0; x < 128; x++) {
                    int sx = x * image.getWidth() / 128;
                    int sy = y * image.getHeight() / 128;
                    int argb = image.getRGB(sx, sy);
                    result[y * 128 + x] = MapColorQuantizer.quantize(argb);
                }
            }
            return result;
        }
    }

    private static void message(String text) {
        Minecraft mc = Minecraft.getInstance();
        mc.gui.getChat().addMessage(net.minecraft.network.chat.Component.literal(text));
    }
}
